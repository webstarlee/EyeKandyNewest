    <!-- BEGIN: Footer-->
<footer style="background: linear-gradient(45deg, #0e0e0e, #272727) !important;" class="page-footer footer footer-static footer-dark gradient-45deg-purple-deep-orange gradient-shadow navbar-border navbar-shadow">
      <div class="footer-copyright">
        <div class="container"><span>&copy; 2019          <a href="http://themeforest.net/user/pixinvent/portfolio?ref=pixinvent" target="_blank">PIXINVENT</a> All rights reserved.</span><span class="right hide-on-small-only">Design and Developed by <a href="https://pixinvent.com/">PIXINVENT</a></span></div>
      </div>
    </footer>

    <!-- END: Footer-->
    <!-- BEGIN VENDOR JS-->
    <script src="materialize-admin-template-5.1/materialize-admin-template/app-assets/js/vendors.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="materialize-admin-template-5.1/materialize-admin-template/app-assets/vendors/chartjs/chart.min.js" type="text/javascript"></script>
    <script src="materialize-admin-template-5.1/materialize-admin-template/app-assets/vendors/chartist-js/chartist.min.js" type="text/javascript"></script>
    <script src="materialize-admin-template-5.1/materialize-admin-template/app-assets/vendors/chartist-js/chartist-plugin-tooltip.js" type="text/javascript"></script>
    <script src="materialize-admin-template-5.1/materialize-admin-template/app-assets/vendors/chartist-js/chartist-plugin-fill-donut.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN THEME  JS-->
    <script src="materialize-admin-template-5.1/materialize-admin-template/app-assets/js/plugins.js" type="text/javascript"></script>
    <script src="materialize-admin-template-5.1/materialize-admin-template/app-assets/js/custom/custom-script.js" type="text/javascript"></script>
    <!-- END THEME  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="materialize-admin-template-5.1/materialize-admin-template/app-assets/js/scripts/dashboard-modern.js" type="text/javascript"></script>
    <script src="materialize-admin-template-5.1/materialize-admin-template/app-assets/js/scripts/intro.js" type="text/javascript"></script>
    <!-- END PAGE LEVEL JS-->
    <script src="assets/js/jquery.canvasjs.min.js"></script>      
    <script src="assets/js/dataTables.min.js"></script>  
    <script src="assets/js/jquery.modal.min.js"></script>     
    <!-- <script src="app-assets/js/scripts/eCommerce-products-page.js" type="text/javascript"></script>  
    <script src="app-assets/vendors/noUiSlider/nouislider.min.js" type="text/javascript"></script> -->
    <script src="assets/js/customize.js"></script>
    
  </body>
</html>