<?php require('./header.php');
        require('./sidebar5.php');
 ?>  
<div id="main">
<!--Page Content-->
<main id="pageContent" class="page has-sidebar" >
    <div class="container-fluid relative animatedParent animateOnce" style="padding-top:0px !important;">
        <div class="animated fadeInUpShort p-5 ml-lg-5 mr-lg-5 go">
            <section class="product">
                <!-- <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="card animate fadeUp">                     
                            <div class="card-content">
                                <div class="card-badge"><a class="white-text"> <b>On Offer</b> </a></div>
                                <div class="row" id="product-four">                                
                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                        <a href="http://www.amazon.co.uk/?_encoding=UTF8&amp;camp=1634&amp;creative=6738&amp;linkCode=ur2&amp;tag=webcamodel-21">
                                            <img src="./assets/img/amazon.jpg" class="responsive-img" alt="">
                                        </a>
                                    </div>
                                    <div class="col-lg-8 col-md-8 col-sm-8">                                
                                        <h3><span class="fontpink">A</span>MAZON</h3>
                                        <hr>
                                        <h5>AMAZON IS THE NUMBER ONE PLACE TO BUY ALL OF YOUR EQUIPMENT</h5>
                                        <p>YOU CAN SEARCH FOR MULTIPLE ITEMS SUCH AS:</p>
                                        <ul>
                                            <li>HD WEBCAMS</li>
                                            <li>LAPTOPS</li>
                                            <li>COMPUTERS</li>
                                            <li>LIGHTING</li>
                                            <li>+ MUCH MORE!</li>
                                            <li>FREE DELIVERY ON MOST ORDERS OVER E201</li>                                        
                                        </ul>                                    
                                        <a href="http://www.amazon.co.uk/?_encoding=UTF8&amp;camp=1634&amp;creative=6738&amp;linkCode=ur2&amp;tag=webcamodel-21" class="btn btn-primary btn-lg mynavbar-btn" style="color:white">Show More</a>                                    
                                        
                                    </div>
                                </div>
                            </div>                                
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="card animate fadeUp">                     
                            <div class="card-content">
                                <div class="card-badge"><a class="white-text"> <b>On Offer</b> </a></div>
                                <div class="row" id="product-four">
                                    
                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                        <a href="http://track.webgains.com/click.html?wgcampaignid=205405&wgprogramid=12161">                                   
                                            <img src="./assets/img/lovehoney.jpg" class="responsive-img" alt="">
                                        </a>
                                    </div>
                                    <div class="col-lg-8 col-md-8 col-sm-8">                                
                                        <h3><span class="fontpink">A</span>MAZON</h3>
                                        <hr>
                                        <h5>AMAZON IS THE NUMBER ONE PLACE TO BUY ALL OF YOUR EQUIPMENT</h5>
                                        <p>YOU CAN SEARCH FOR MULTIPLE ITEMS SUCH AS:</p>
                                        <ul>
                                            <li>HD WEBCAMS</li>
                                            <li>LAPTOPS</li>
                                            <li>COMPUTERS</li>
                                            <li>LIGHTING</li>
                                            <li>+ MUCH MORE!</li>
                                            <li>FREE DELIVERY ON MOST ORDERS OVER E201</li>                                        
                                        </ul>                                    
                                        <a href="http://track.webgains.com/click.html?wgcampaignid=205405&wgprogramid=12161" class="btn btn-primary btn-lg" style="color:white">Show More</a>                                    
                                        
                                    </div>
                                </div>
                            </div>                                
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="card animate fadeUp">                     
                            <div class="card-content">
                                <div class="card-badge"><a class="white-text"> <b>On Offer</b> </a></div>
                                <div class="row" id="product-four">
                                    
                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                        <a href="https://www.lovense.com/bluetooth-remote-control-vibrator?idev_id=11-c0d3ef9af9fd44b4a9c5f34ec6fc5918&type_id=1&ofid=hjd2k">                                   
                                            <img src="./assets/img/lovence.jpg" class="responsive-img" alt="">
                                        </a> 
                                    </div>
                                    <div class="col-lg-8 col-md-8 col-sm-8">                                
                                        <h3><span class="fontpink">A</span>MAZON</h3>
                                        <hr>
                                        <h5>AMAZON IS THE NUMBER ONE PLACE TO BUY ALL OF YOUR EQUIPMENT</h5>
                                        <p>YOU CAN SEARCH FOR MULTIPLE ITEMS SUCH AS:</p>
                                        <ul>
                                            <li>HD WEBCAMS</li>
                                            <li>LAPTOPS</li>
                                            <li>COMPUTERS</li>
                                            <li>LIGHTING</li>
                                            <li>+ MUCH MORE!</li>
                                            <li>FREE DELIVERY ON MOST ORDERS OVER E201</li>                                        
                                        </ul>                                    
                                        <a href="https://www.lovense.com/bluetooth-remote-control-vibrator?idev_id=11-c0d3ef9af9fd44b4a9c5f34ec6fc5918&type_id=1&ofid=hjd2k" class="btn btn-primary btn-lg mynavbar-btn" style="color:white">Show More</a>                                    
                                        
                                    </div>
                                </div>
                            </div>                                
                        </div>
                    </div>
                </div> -->
                <div class="row">
                    <div class="col s12 m6 l4">
                      <div class="card-panel border-radius-6 mt-10 card-animation-1">
                        <a href="http://www.amazon.co.uk/?_encoding=UTF8&amp;camp=1634&amp;creative=6738&amp;linkCode=ur2&amp;tag=webcamodel-21"><img class="responsive-img border-radius-8 z-depth-4 image-n-margin" src="../dashboard/materialize-admin-template-5.1/materialize-admin-template/app-assets/images/cards/amazon.png"
                            alt=""></a>
                        <h6 class="deep-purple-text text-darken-3 mt-5"><a href="#">Amazon</a></h6>
                        <span>Amaon is the number one place to buy all of your equipment.</span>
                        <div class="row mt-4">
                          <div class="col s5 mt-1">
                            <img src="../dashboard/materialize-admin-template-5.1/materialize-admin-template/app-assets/images/cards/amazon.png" alt="fashion" class="circle mr-3 width-30 vertical-text-middle">
                            <span class="pt-2">Amazon</span>
                          </div>
                          <div class="col s7 mt-3 right-align social-icon">
                            <span class="material-icons">add_shopping_cart</span>
                            
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- Apple News -->
                    <div class="col s12 m6 l4">
                      <div class="card-panel border-radius-6 mt-10 card-animation-1">
                        <a href="http://track.webgains.com/click.html?wgcampaignid=205405&wgprogramid=12161"><img class="responsive-img border-radius-8 z-depth-4 image-n-margin" src="../dashboard/materialize-admin-template-5.1/materialize-admin-template/app-assets/images/cards/lovehoney.png"
                            alt=""></a>
                        <h6 class="deep-purple-text text-darken-3 mt-5"><a href="#">Lovehoney</a></h6>
                        <span style="font-size: 14px;">Amazon is the number one place to buy all of your equipment.</span>
                        <div class="row mt-4">
                          <div class="col s5 mt-1">
                            <img src="../dashboard/materialize-admin-template-5.1/materialize-admin-template/app-assets/images/cards/lovehoney.png" alt="news" class="circle mr-3 width-30 vertical-text-middle">
                            <span class="pt-2">Lovehoney</span>
                          </div>
                          <div class="col s7 mt-3 right-align social-icon">
                            <span class="material-icons">shopping_basket</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- Twitter News -->
                    <div class="col s12 m6 l4">
                      <div class="card-panel border-radius-6 mt-10 card-animation-1">
                        <a href="https://www.lovense.com/bluetooth-remote-control-vibrator?idev_id=11-c0d3ef9af9fd44b4a9c5f34ec6fc5918&type_id=1&ofid=hjd2k"><img class="responsive-img border-radius-8 z-depth-4 image-n-margin" src="../dashboard/materialize-admin-template-5.1/materialize-admin-template/app-assets/images/cards/lovense.png"
                            alt=""></a>
                        <h6 class="deep-purple-text text-darken-3 mt-5"><a href="#">Lovense</a></h6>
                        
                        <span style="font-size: 14px;">Amaon is the number one place to buy all of your equipment.
                        </span>
                        <div class="row mt-4">
                          <div class="col s5 p-0 mt-1">
                            <img src="../dashboard/materialize-admin-template-5.1/materialize-admin-template/app-assets/images/cards/lovense.png" alt="news" class="circle mr-3 width-30 vertical-text-middle">
                            <span class="pt-2">Lovense</span>
                          </div>
                          <div class="col s7 mt-3 right-align social-icon">
                            <span class="material-icons">shopping_cart</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- Blog Style Two -->
                </div>
                <div class="row">
                <!-- Share markets News -->
                    <div class="col s12 m6 l4">
                      <div style="background: linear-gradient(45deg, #b297e0, #7a56af) !important;" class="card-panel border-radius-6 white-text gradient-45deg-deep-purple-blue card-animation-2">
                        <h6 class="mt-5"><b><a href="#" class="white-text">You can search for multiple items such as:</a></b></h6>
                        <span>HD WEBCAMS, LAPTOPS, COMPUTERS, LIGHTING, + MUCH MORE!, FREE DELIVERY ON MOST ORDERS OVER,  E201             
                        </span>
                        <div class="row mt-4">
                          <div class="col s5 mt-1">
                            
                          </div>
                          <div class="col s7 mt-3 right-align social-icon">
                            <span class="material-icons">add_shopping_cart</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- USA News -->
                    <div class="col s12 m6 l4">
                      <div style="background: linear-gradient(45deg, #7a56af, #f5109c) !important;" class="card-panel border-radius-6 white-text gradient-45deg-purple-deep-orange card-animation-2">
                        <h6 class="mt-5"><b><a href="#" class="white-text">You can search for multiple items such as:</a></b></h6>
                        <span>HD WEBCAMS, LAPTOPS, COMPUTERS, LIGHTING, + MUCH MORE!, FREE DELIVERY ON MOST ORDERS OVER,  E201             
                        </span>
                        <div class="row mt-4">
                          <div class="col s5 mt-1">
                            
                          </div>
                          <div class="col s7 mt-3 right-align social-icon">
                            <span class="material-icons">shopping_basket</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- Fasion News -->
                    <div class="col s12 m6 l4">
                      <div style="background: linear-gradient(45deg, #f5109c, #ecb5db) !important;" class="card-panel border-radius-6 white-text gradient-45deg-indigo-light-blue card-animation-2">
                        <h6 class="mt-5"><b><a href="#" class="white-text">You can search for multiple items such as:</a></b></h6>
                        <span>HD WEBCAMS, LAPTOPS, COMPUTERS, LIGHTING, + MUCH MORE!, FREE DELIVERY ON MOST ORDERS OVER,  E201             
                        </span>

                        <div class="row mt-4">
                          <div class="col s5 p-0 mt-1">
                            
                          </div>
                          <div class="col s7 mt-3 right-align social-icon">
                            <span class="material-icons">shopping_cart</span>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>

            </section>
    </div>

</main><!--@Page Content-->
</div><!--@#app-->
<?php require('.//footer.php'); ?>